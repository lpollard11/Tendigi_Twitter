//
//  TDWebViewController.h
//  Tendigi_Twitter
//
//  Created by Lee Pollard on 4/23/15.
//  Copyright (c) 2015 Tendigi. All rights reserved.
//

#import <UIKit/UIKit.h>





@interface TDWebViewController : UIViewController

@property (nonatomic, strong) NSURL *url;

@end
