//
//  AppDelegate.h
//  Tendigi_Twitter
//
//  Created by Lee Pollard on 4/23/15.
//  Copyright (c) 2015 Tendigi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

